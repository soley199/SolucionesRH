<?php
if(!isset($_POST['nombre'])){
    var_dump("Ningunvalor");
  
} else{
    

  $nombre = $_POST['nombre'];
  $telefono = $_POST['telefono'];
  $email = $_POST['email'];
  $mensaje = $_POST['mensaje'];
                                                                                                                                                                                                                                                                  
}
